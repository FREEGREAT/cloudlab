const AWS = require("aws-sdk");
const dynamoDB = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context) => {
  const id = event.id;

  const params = {
    TableName: process.env.TABLE_NAME,
    Key: {
      id: id
    }
  };

  try {
    const data = await dynamoDB.get(params).promise();

    if (!data.Item) {
      return {
        statusCode: 404,
        body: JSON.stringify({ message: 'Item not found' }),
      };
    }

    const formattedData = {
      Items: [
        {
          id: { S: data.Item.id },
          title: { S: data.Item.title },
          authorId: { S: data.Item.authorId },
          length: { S: data.Item.length },
          category:{S: data.Item.category}
        }
      ]
    };

    return {
      statusCode: 200,
      body: JSON.stringify(formattedData),
    };
  } catch (error) {
    console.error('Error getting item', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Error getting item' }),
    };
  }
};
